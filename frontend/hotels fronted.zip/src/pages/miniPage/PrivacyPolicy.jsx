import React from 'react'

const PrivacyPolicy = () => {
  return (
    <div>Privacy Policy page</div>
  )
}

export default PrivacyPolicy